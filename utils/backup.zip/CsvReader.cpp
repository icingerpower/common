#include <QtCore/qfile.h>
#include <QtCore/qtextstream.h>

#include "CsvReader.h"


//----------------------------------------------------------
CsvReader::CsvReader(const QString &fileName,
        QString sep,
        QString guillemetsForString,
        bool hasHeader,
        QString returnLine,
        int nHeaders)
{
    m_fileName = fileName;
    m_sep = sep;
    m_hasHeader = hasHeader;
    m_guillemetsForString = guillemetsForString;
    Q_ASSERT(guillemetsForString.size() == 1);
    Q_ASSERT(sep.size() == 1);
    m_returnLine = returnLine;
    m_nHeaders = nHeaders;
    m_file = nullptr;
}
//----------------------------------------------------------
CsvReader::~CsvReader()
{
    if (m_file != nullptr) {
        close();
    }
}
//----------------------------------------------------------
bool CsvReader::isLinuxReturnLine(QString &fileName)
{
    bool is = false;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        file.seek(0);
        QString firstData = stream.read(line.length()*2+2);
        is = !firstData.contains("\r\n");
    }
    return is;
}
//----------------------------------------------------------
bool CsvReader::isValidHeader(
        const QString &fileName, const QStringList &elements)
{
    bool is = false;
    QFile file(fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        is = true;
        for (auto element : elements) {
            if (!line.contains(element)){
                is = false;
                break;
            }
        }
    }
    return is;
}
//----------------------------------------------------------
bool CsvReader::isValidHeader(const QStringList &elements) const
{
    bool is = CsvReader::isValidHeader(m_fileName, elements);
    return is;
}
//----------------------------------------------------------
bool CsvReader::readAll()
{
    m_dataRode.lines.clear();
    QFile file(m_fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        if (m_hasHeader) {
            QStringList headerElements = decodeLine(line);
            m_dataRode.headers << CsvHeader(headerElements);
        }
        if (m_nHeaders > 1) {
            for (int i=0; i<m_nHeaders-1; ++i) {
                line = stream.readLine();
                QStringList headerElements2 = decodeLine(line);
                m_dataRode.headers << CsvHeader(headerElements2);
            }
        }
        while (true) {
            line = stream.readLine();
            line = line.replace("\"\"", "''");
            if (line.isEmpty()) {
                break;
            } else {
                QStringList decodedLine = decodeLine(line);
                m_dataRode.lines << decodedLine;
            }
        }
        file.close();
        return true;
    }
    return false;
}
//----------------------------------------------------------
bool CsvReader::readSomeLines(int nLines)
{
    m_dataRode.lines.clear();
    QFile file(m_fileName);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream stream(&file);
        QString line = stream.readLine();
        if (m_hasHeader) {
            QStringList headerElements = decodeLine(line);
            m_dataRode.headers << CsvHeader(headerElements);
        }
        if (m_nHeaders > 1) {
            for (int i=0; i<m_nHeaders-1; ++i) {
                line = stream.readLine();
                QStringList headerElements2 = decodeLine(line);
                m_dataRode.headers << CsvHeader(headerElements2);
            }
        }
        int curLine = 0;
        while (curLine < nLines) {
            line = stream.readLine();
            line = line.replace("\"\"", "''");
            if (line.isEmpty()) {
                break;
            } else {
                QStringList decodedLine = decodeLine(line);
                m_dataRode.lines << decodedLine;
            }
            ++curLine;
        }
        file.close();
        return true;
    }
    return false;
}
//----------------------------------------------------------
const DataFromCsv *CsvReader::dataRode() const
{
    return &m_dataRode;
}
//----------------------------------------------------------
void CsvReader::removeFirstLine()
{
    if (m_dataRode.lines.size() > 0) {
        m_dataRode.lines.removeAt(0);
    }
}
//----------------------------------------------------------
QStringList CsvReader::takeFirstLine()
{
    QStringList elements = m_dataRode.lines.takeAt(0);
    return elements;
}
//----------------------------------------------------------
bool CsvReader::open()
{
    if (m_file != nullptr) {
        close();
    }
    m_file = new QFile(m_fileName);
    bool success = m_file->open(QFile::ReadOnly);
    if (success) {
        m_stream = new QTextStream(m_file);
    }
    return success;
}
//----------------------------------------------------------
void CsvReader::readAllCsv()
{
    m_dataRode.lines.clear();
    while(!m_stream->atEnd()) {
        m_dataRode.lines << readCsvLine();
    }
    if (m_hasHeader) {
        for (int i=0; i<m_nHeaders; ++i) {
            m_dataRode.headers << CsvHeader(m_dataRode.lines.takeFirst());
        }
    }
}
//----------------------------------------------------------
void CsvReader::readSomeCsvLines(int nLines)
{
    for (int i=0; i<nLines && !m_stream->atEnd(); ++i) {
        m_dataRode.lines << readCsvLine();
    }
    if (m_hasHeader && m_nHeaders > m_dataRode.headers.size()) {
        int nHeadersLeft = qMin(m_nHeaders - m_dataRode.headers.size(), m_dataRode.lines.size());
        for (int i=0; i<nHeadersLeft; ++i) {
            m_dataRode.headers << CsvHeader(m_dataRode.lines.takeFirst());
        }
    }
}
//----------------------------------------------------------
QStringList CsvReader::readCsvLine()
{
    QStringList elements;
    QString element;
    while (!m_stream->atEnd()) {
        QString chars = m_stream->read(1);
        if (chars == m_guillemetsForString) {
            /// We are in guillemet elements
            while (!m_stream->atEnd()
                   && !((element.endsWith(m_sep)
                         || element.endsWith("\n")
                         || element.endsWith("\r"))
                        && element.size() > 1 && element[element.size()-2] == m_guillemetsForString)) {
                element += m_stream->read(1);
            }
            while (!element.endsWith(m_guillemetsForString)) {
                element += m_stream->read(1);
            }
            elements << element.left(element.size() - 1);
            element.clear();
            QString nextChar = m_stream->read(1); // sep or return line
            if (nextChar == "\n" || nextChar == "\r") {
                if (nextChar == "\r") {
                    m_stream->read(1);
                }
                elements << element;
                return elements;
            }
        } else if (chars.contains("\n") || chars.contains("\r")) {
            if (chars.contains("\r")) {
                m_stream->read(1);
            }
            return elements;
        } else {
            while (!element.endsWith(m_sep)
                   && !element.endsWith("\n")
                   && !element.endsWith("\r")
                   && !m_stream->atEnd()) {
                element += m_stream->read(1);
            }
            if (elements.endsWith("\r")) {
                m_stream->read(1);
                elements << element.left(element.size() - 1);
                element.clear();
                return elements;
            } else if (elements.endsWith("\n") || m_stream->atEnd()) {
                elements << element.left(element.size() - 1);
                element.clear();
                return elements;
            } else if (elements.endsWith(m_sep)) {
                elements << element.left(element.size() - 1);
                element.clear();
            }
        }
    }
    return elements;
}
//----------------------------------------------------------
void CsvReader::close()
{
    if (m_file != nullptr) {
        m_file->close();
        delete m_stream;
        delete m_file;
        m_file = nullptr;
        m_stream = nullptr;
    }
}
//----------------------------------------------------------
QStringList CsvReader::decodeLine(const QString &line) const
{
    QStringList elements;
    if (m_guillemetsForString.isEmpty()) {
        elements = line.split(m_sep);
    } else {
        int lenSep = m_sep.length();
        int lenGuill = m_guillemetsForString.length();
        QString lineCopy = line.trimmed();
        bool end = false;
        while(!end) {
            if (lineCopy.startsWith(m_guillemetsForString)) {
                lineCopy.remove(0, lenGuill);
                int indexEnd = lineCopy.indexOf(m_guillemetsForString);
                QString element = lineCopy.left(indexEnd);
                elements << element;
                lineCopy.remove(0, indexEnd + lenSep + lenGuill);
            } else {
                int indexEnd = lineCopy.indexOf(m_sep);
                QString element = lineCopy.left(indexEnd);
                elements << element;
                lineCopy.remove(0, indexEnd + lenSep);
            }
            end = lineCopy.isEmpty();
        }
    }
    return elements;
}
//----------------------------------------------------------

