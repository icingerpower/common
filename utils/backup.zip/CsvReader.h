#ifndef CSVREADER_H
#define CSVREADER_H

#include <QtCore/qstring.h>
#include <QtCore/qhash.h>
#include <QtCore/qstringlist.h>
#include <QtCore/qlist.h>
#include <QtCore/qfile.h>
#include <QtCore/qtextstream.h>

#include "CsvHeader.h"

struct DataFromCsv {
    QList<CsvHeader> headers;
    QList<QStringList> lines;
};

class CsvReader
{
public:
    CsvReader(const QString &fileName,
              QString sep = ",",
              QString guillemetsForString = "",
              bool hasHeader = true,
              QString returnLine = "\n",
              int nHeaders = 1);
    ~CsvReader();
    static bool isLinuxReturnLine(QString &fileName);
    static bool isValidHeader(
            const QString &fileName, const QStringList &elements);

    bool isValidHeader(const QStringList &elements) const;
    bool readAll();
    bool readSomeLines(int nLines);
    const DataFromCsv *dataRode() const;
    void removeFirstLine();
    QStringList takeFirstLine();

    bool open();
    void close();
    void readAllCsv();
    void readSomeCsvLines(int nLines);

private:
    QStringList readCsvLine();
    QStringList decodeLine(const QString &line) const;
    QString m_fileName;
    QString m_guillemetsForString;
    bool m_hasHeader;
    QString m_sep;
    QString m_returnLine;
    DataFromCsv m_dataRode;
    int m_nHeaders;
    QFile *m_file;
    QTextStream *m_stream;
};


#endif // CSVREADER_H
